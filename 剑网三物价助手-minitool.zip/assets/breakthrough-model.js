/* 突破计算模型。Web / 小工具副本由 scripts/sync-breakthrough-model.mjs 同步。 */
function createBreakthrough(BT, catalog, getState) {
  'use strict';
  const QUOTE_KEYS = {"玄元星平衫":"7_112590","地脉玄元":"5_89566","蜂王浆":"5_30854","兽皮胶":"5_30851","七彩线":"5_89960","百染线":"5_10175","玄元星平鞋":"7_112572","玄元星平护腕":"7_112560","风语·衣·绣（气血）":"5_71208","猫眼石":"5_30852","珠贝母":"5_30853","宝石":"5_30828","绢带":"5_89165","棉线":"5_32000","挂件包·背部":"5_7165","百花布":"5_89956","挂件包·腰部":"5_7166","蜀染布":"5_89957","纺丝":"5_32001","蜀染布包":"8_53","百股线":"5_10173","锦缝春山囊":"8_36275","五色石":"5_89958","鸡血石":"5_30856","沉香木":"5_30855","隔音帐":"5_71422","青魄玉":"5_89298","硼砂":"5_30679","石灰":"5_32004","银鳞":"5_30847","玛瑙":"5_30846","银丝缎":"5_89959","百花线":"5_32003","紫檀":"5_30848","金线":"5_32002","玄元木声衫":"7_112589","辉石":"5_30850","玄元松绿衫":"7_112588","云芝":"5_30845","绝世上衣·【寒】":"5_31231","蜃楼珠":"5_31397","蜀锦绣·腕（身法）":"5_89433","蜀锦绣·腕（力道）":"5_89435","寻踪觅宝·护手":"5_31253","同袍营幡":"5_90033","黄花菜":"5_30844","黄蜡":"5_89166","璧·苍生":"5_89568","玄元烽火鞋":"7_112569","境华":"5_90338","玄元赤地鞋":"7_112568","绝世鞋子·【寒】":"5_31239","玄元赤地护腕":"7_112556","玄元烽火护腕":"7_112557","绝世护腕·【寒】":"5_31235","驾驾伪装":"5_90210","麻絮":"5_35718","滑石粉":"5_35719","羊皮":"5_30873","哼唧伪装":"5_90205","灯笼":"8_614","山水刺绣手绢":"5_2466","刺绣手绢":"5_3819","小香包":"5_3779","彩缕花绫包":"8_36148","棉布包":"8_19","河洛纹·鞋（跑速）":"5_89475","河洛纹·衣（御劲）":"5_89474","丹青染布画":"5_3820","百炼水煮鱼":"5_89321","鱼肉":"5_30827","酱料":"5_89970","今朝醉":"5_32014","胡椒粉":"5_31978","红辣椒":"5_31985","路菜":"5_76622","西市腔":"5_1831","精制面粉":"5_31973","人参":"5_30849","风语·老火骨汤":"5_71293","骨头":"5_30826","血":"5_30825","藤椒":"5_89171","料酒":"5_31974","菌菇":"5_31968","风语·三鲜汤":"5_71292","精肉":"5_30824","新鲜冬瓜":"5_31967","风语·鲜肉包子":"5_71281","碎肉":"5_30823","老姜":"5_31969","风语·水煮肉片":"5_71277","云中珍馐宴（通用）":"5_89315","竹叶青":"5_1829","馅料":"5_89969","调料":"5_31976","巴渝珍馐宴（通用）":"5_89303","卤料":"5_89971","露水":"5_30840","羊杂":"5_30875","蛋":"5_30829","鱼腥草":"5_30843","羊肉":"5_30874","紫苏":"5_30842","饺子馅":"5_5270","大葱":"5_31970","饺子皮":"5_5269","生粉":"5_31977","转神餐":"5_31013","甘草":"5_30830","佛跳墙":"5_31012","安营炊鼎":"5_90034","酥油":"5_89172","巴山夜雨宴（外攻）":"5_89304","炼狱水煮鱼":"5_24212","膘然心动":"5_26057","如意饺":"5_26231","云州刀削面":"5_89352","山城毛血旺":"5_89350","风语·红烧排骨":"5_71269","云芝竹沥羹":"5_89346","竹沥":"5_89167","老豆腐":"5_31984","开锅豆腐":"5_89348","风语·杂锦鱼球粥":"5_71285","截元丹":"5_31101","虫草":"5_30836","千里香":"5_30832","枸杞":"5_30833","葫芦":"5_31997","竹沥凝心饮":"5_89324","大黄":"5_30831","药丸":"5_89973","药囊":"5_31996","风语·中品万灵丹":"5_71241","风语·上品万灵丹":"5_71240","药罐":"5_31995","风语·中品大力丸":"5_71266","彼岸花":"5_30838","珊瑚":"5_30839","药料":"5_6646","云州固阵丹":"5_89333","五味子":"5_30835","药膏":"5_89974","药用黄丹":"5_6648","风语·中品静心丸":"5_71267","回神丹":"5_90029","药曲":"5_89168","药引":"5_89972","金针·影":"5_31100","竹沥清心露":"5_89322","芍药":"5_30837","踏波露":"5_90206","飞鱼丸":"5_31102","川贝":"5_30834","金针":"5_31998","定魂丹砂":"5_90035","巴山凝神丹":"5_89328","河洛生息丹":"5_89332","巴山凝神散":"5_89340","五气归元丹":"5_89325","风语·上品健体丸":"5_71258","银针":"5_31999","五气培元丸":"5_89327","苍生·巨灵磨石（仇恨）":"5_89378","镔铁锭":"5_89966","炼火石":"5_10176","火墨":"5_31991","苍生·絮泊磨石（疗伤）":"5_89377","铅锭":"5_89968","煤炭":"5_31993","苍生·坠宵磨石（攻击）":"5_89376","锡锭":"5_89965","木炭":"5_31992","苍生·瀑沙磨石（武伤）":"5_89375","黄铜锭":"5_89963","苍生·巨灵熔锭（仇恨）":"5_89370","风语·巨灵磨石（仇恨）":"5_71192","松脂":"5_89169","风语·兵·甲（仇恨）":"5_71188","菜籽油":"5_31994","玄元星平帽":"7_112584","密银锭":"5_89962","玄元星平护腰":"7_112566","玄元星平裤":"7_112578","龙血磨石":"5_31139","青铜锭":"5_89964","素银钥匙":"5_10027","熟铁锭":"5_89961","素银钥匙模":"5_10029","铁矿":"5_30677","铅锌矿":"5_30676","银矿":"5_30678","铜矿":"5_30674","锡矿":"5_30675","生铁锭":"5_89967","苍生·瀑沙熔锭（武伤）":"5_89367","青铜钥匙":"5_6246","青铜钥匙模":"5_6249","玄元烽火裤":"7_112575","玄元风鹤裤":"7_112573","绝世下装·【兹】":"5_31209","切玉骨":"5_32787","玄元松绿护腰":"7_112564","玄元风鹤护腰":"7_112561","绝世腰带·【兹】":"5_31211","寄青荷":"8_25762","荷叶":"5_30841","旦火油":"5_10172","皮革":"5_35708","银龙笼套":"8_17541","铁纹鞍具":"8_17538","玄元松绿帽":"7_112582","玄元木声帽":"7_112583","绝世头饰·【兹】":"5_31210","定营铁桩":"5_90032","熟矾":"5_89170","珠·苍生":"5_89567","玄武腰刀":"8_632","青龙腰刀":"8_634","麒麟腰刀":"8_636","同门饕餮鼎":"5_90353","飞高高":"5_90257","铜偶":"5_2578","鞭炮":"5_6072","龙凤呈祥":"5_6068","元宝灯":"5_6066","木板":"5_35712","木料":"5_35566","清漆":"5_35707","绳索":"5_35703","器物令":"5_38831","鱼胶":"5_35716","黏土":"5_35702","篾条":"5_35715","竹子":"5_35568","芦苇杆":"5_35567","油布":"5_35704","雕花":"5_35714","石材":"5_35701","卯榫":"5_35713","楔子":"5_35705","清漆药柜":"10_1778","简素椅":"10_948","归营旌":"5_89260","锻炉":"10_1779","残烛柜架":"10_1880","矩形回纹格":"10_2034","葵草席":"10_93","禅心悬旗":"10_1882","阎家样":"5_35717","铜雕踩球对狮·右":"10_2037","素髹桑木灯檠":"10_164","地下室·8米木质标准包":"5_52337","竹篾篱·套件":"5_40232","兖石地墁·套件":"5_35772","飞毛腿伪装":"5_90211","拼布自选包":"5_87917","铃兰·混彩":"10_1167","拼布72色全包":"5_87881","杂碎":"5_30682","金沙":"5_30681","青石":"5_30680","酥油烧饼":"5_89353","酥油烧饼·精":"5_89359","菹菜拌腱肉":"5_89354","菹菜拌腱肉·精":"5_89360","嘉陵月夜宴（内攻）":"5_89305","未央宫庭宴（内攻）":"5_89311","椒香暖玉宴（治疗）":"5_89306","渭水清和宴（治疗）":"5_89312","红汤沸鼎宴（仇恨）":"5_89307","秦川鼎烹宴（仇恨）":"5_89313","朝天门宴（防御）":"5_89308","函谷关宴（防御）":"5_89314","渝州小面":"5_89349","渝州小面·精":"5_89355","藤椒鱼片":"5_89351","藤椒鱼片·精":"5_89357","蜀锦绣·腕（元气）":"5_89434","云锦绣·腕（元气）":"5_89448","蜀锦绣·腕（根骨）":"5_89436","云锦绣·腕（根骨）":"5_89450","蜀锦绣·腕（仇恨）":"5_89437","云锦绣·腕（仇恨）":"5_89451","蜀锦绣·腕（破防）":"5_89438","云锦绣·腕（破防）":"5_89452","蜀锦绣·腕（会心）":"5_89439","云锦绣·腕（会心）":"5_89453","蜀锦绣·腕（无双）":"5_89440","云锦绣·腕（无双）":"5_89454","蜀锦绣·鞋（攻击）":"5_89441","云锦绣·鞋（攻击）":"5_89455","蜀锦绣·鞋（治疗）":"5_89442","云锦绣·鞋（治疗）":"5_89456","蜀锦绣·鞋（加速）":"5_89443","云锦绣·鞋（加速）":"5_89457","蜀锦绣·衣（体质）":"5_89444","云锦绣·衣（体质）":"5_89458","蜀锦绣·衣（化劲）":"5_89445","云锦绣·衣（化劲）":"5_89459","蜀锦绣·衣（御劲）":"5_89446","云锦绣·衣（御劲）":"5_89460","玄元赤地衫":"7_112586","玄元烽火衫":"7_112587","玄元风鹤衫":"7_112585","玄元风鹤鞋":"7_112567","无观鞋·内·荒":"7_112789","玄元木声鞋":"7_112571","玄元松绿鞋":"7_112570","无观鞋·外·荒":"7_112792","玄元风鹤护腕":"7_112555","玄元木声护腕":"7_112559","玄元松绿护腕":"7_112558","渝州摧锋丹":"5_89329","渝州摧锋丹·精":"5_89335","函谷疾咏丹":"5_89330","函谷疾咏丹·精":"5_89336","中原破阵丹":"5_89331","中原破阵丹·精":"5_89337","苍生·坠宵熔锭（攻击）":"5_89368","苍生·坠宵焠晶（攻击）":"5_89372","苍生·絮泊熔锭（疗伤）":"5_89369","苍生·絮泊焠晶（疗伤）":"5_89373","青石锭":"5_90436","峡金铸·兵（攻击）":"5_89379","峡金焠·兵（攻击）":"5_89397","峡金铸·兵（疗伤）":"5_89380","峡金焠·兵（疗伤）":"5_89398","镀金锭":"5_90437","峡金铸·兵（武伤）":"5_89381","峡金焠·兵（武伤）":"5_89399","峡金铸·兵（仇恨）":"5_89382","峡金焠·兵（仇恨）":"5_89400","峡金铸·裤（身法）":"5_89383","峡金焠·裤（身法）":"5_89401","峡金铸·裤（元气）":"5_89384","峡金焠·裤（元气）":"5_89402","峡金铸·裤（力道）":"5_89385","峡金焠·裤（力道）":"5_89403","峡金铸·裤（根骨）":"5_89386","峡金焠·裤（根骨）":"5_89404","峡金铸·裤（仇恨）":"5_89387","峡金焠·裤（仇恨）":"5_89405","峡金铸·裤（破防）":"5_89388","峡金焠·裤（破防）":"5_89406","峡金铸·裤（会心）":"5_89389","峡金焠·裤（会心）":"5_89407","峡金铸·裤（无双）":"5_89390","峡金焠·裤（无双）":"5_89408","峡金铸·头（攻击）":"5_89391","峡金焠·头（攻击）":"5_89409","峡金铸·头（治疗）":"5_89392","峡金焠·头（治疗）":"5_89410","峡金铸·头（加速）":"5_89393","峡金焠·头（加速）":"5_89411","峡金铸·腰（体质）":"5_89394","峡金焠·腰（体质）":"5_89412","峡金铸·腰（御劲）":"5_89395","峡金焠·腰（御劲）":"5_89413","峡金铸·腰（化劲）":"5_89396","峡金焠·腰（化劲）":"5_89414","云冈石·兵（仇恨）":"5_89432","玄元赤地帽":"7_112580","无观冠·内·荒":"7_112783","玄元烽火帽":"7_112581","无观冠·外·荒":"7_112786","玄元风鹤帽":"7_112579","玄元赤地护腰":"7_112562","玄元烽火护腰":"7_112563","玄元木声护腰":"7_112565","玄元赤地裤":"7_112574","玄元木声裤":"7_112577","玄元松绿裤":"7_112576","邢窑白瓷罗合":"10_157","咸鱼":"5_20971","积木·木质标准弧料包":"5_38122","匾额·布坊":"10_1281","紫色绣球花":"5_35026","槿花茵·一":"10_1894","红色绣球花":"5_35025","暮春落花·一":"10_2229","胡笳月夜宴（内攻）":"5_89317","鹰鳐纸鸢":"10_2028","须弥座方柱":"10_2241","黄云牧火宴（仇恨）":"5_89319","云中关宴（防御）":"5_89320","云冈石·腰（体质）":"5_89426","云冈石·腰（御劲）":"5_89427","云冈石·腰（化劲）":"5_89428","长安珍馐宴（通用）":"5_89309","华岳开锋宴（外攻）":"5_89310","云芝竹沥羹·精":"5_89347","山城毛血旺·精":"5_89356","云州刀削面·精":"5_89358","云锦绣·腕（身法）":"5_89447","云锦绣·腕（力道）":"5_89449","竹沥清心露·精":"5_89323","五气归元丹·精":"5_89326","巴山凝神丹·精":"5_89334","河洛生息丹·精":"5_89338","云州固阵丹·精":"5_89339","苍生·瀑沙焠晶（武伤）":"5_89371","苍生·巨灵焠晶（仇恨）":"5_89374"}; // generated
  const META = BT.meta || {};
  const CAP = Number(META.levelCap) || 50;
  const GATE_LEVELS = [30, 35, 40, 45];
  const SKILL_IDS = ['shennong', 'caijin', 'paoding', 'duanzao', 'fengren', 'zhiyao', 'pengren', 'zijiang'];
  const MODES = [{ key: 'low', label: '低收益比档' }, { key: 'mid', label: '中收益比档' }, { key: 'high', label: '高收益比档' }];
  const items = BT.items || [], recipes = BT.recipes || [];
  const byName = {}, byId = {}, indexByName = {}, producers = {};
  const catalogByName = {};
  (catalog.items || []).forEach(function (i) { if (i && i.name) catalogByName[i.name] = i; });
  (catalog.items || []).forEach(function (i) { byName[i.name] = i; byId[i.id] = i; });
  items.forEach(function (i, idx) { indexByName[i.n] = idx; });
  recipes.forEach(function (r) { (r.o || []).forEach(function (o) { (producers[o[0]] = producers[o[0]] || []).push(r); }); });
  const num = function (v) { return Number(v) || 0; };
  // 精力→经验换算（用户实测）：采集 40 精力 = 128 经验；制造 1 精力 = 2 经验。
  // 数据里的单次经验（r.x / META.gatherExp）是旧估算，这里按比例统一覆盖。
  // 指定采集路线（用户实测秒刷点），按等级区间固定采集动作。
  const GATHER_PLANS = META.gatherPlans || {};
  // 采集点等级（用户实测，覆盖目录里的旧值）；键为采集点短名。
  const GATHER_LEVELS = META.gatherLevels || {};
  const GATHER_EXTRAS = META.gatherExtras || {};
  const gatherLevelOf = function (r) {
    const name = String((r && (r.n || r.name)) || '');
    const keys = Object.keys(GATHER_LEVELS);
    for (var i = 0; i < keys.length; i++) { if (name.indexOf(keys[i]) !== -1) return num(GATHER_LEVELS[keys[i]]); }
    return num(r && r.level);
  };
  const EXP_PER_ENERGY = META.expPerEnergy || {};
  const GATHER_EXP_PER_ENERGY = num(EXP_PER_ENERGY.gather) || 128 / 40;
  // 30 级以后采集与制造统一为 1 精力 = 2 经验（2026-11-25 用户实测图）。
  const GATHER_EXP_PER_ENERGY_FROM30 = num(EXP_PER_ENERGY.gatherFrom30) || 2;
  function gatherExpPerEnergyAt(level) {
    return level >= 30 ? GATHER_EXP_PER_ENERGY_FROM30 : GATHER_EXP_PER_ENERGY;
  }
  // 目录里缺的采集点用完整配方结构合成，避免界面读取 materials/outputs 时报错
  const synthGatherNode = function (name, energy, level, skillId) {
    const e = num(energy) || 40;
    // 产物按同名物品接上，才能算出产值与收益（否则这些等级收益为 null）
    const item = catalogByName[name] || byName[name];
    return {
      id: 'gather:' + skillId + ':' + name, n: name, name: name, kind: 'gather', skillId: skillId,
      level: num(level) || 1, energy: e, materials: [],
      outputs: item ? [{ item: item.id, qty: 1, chance: 1 }] : [], fee: 0,
      note: '采集点（实测）', verified: true, custom: false, origin: '用户实测采集点'
    };
  };
  const CRAFT_EXP_PER_ENERGY = num(EXP_PER_ENERGY.craft) || 2;
  const itemOf = function (idx) { return items[idx] || { n: '未知物品' }; };
  const skillMeta = function (id) { return (catalog.skills || []).find(function (s) { return s.id === id; }) || { id: id, name: id }; };
  const chanceOf = function (v) { return v == null ? 1 : Math.max(0, Math.min(1, num(v))); };
  const quantity = function (o, mode) { return (mode === 'low' ? o[1] : mode === 'high' ? o[2] : (o[1] + o[2]) / 2) * chanceOf(o[3]); };
  function priceOfIndex(idx, serverId) {
    serverId = serverId || getState().serverId;
    const canon = byName[itemOf(idx).n];
    const primary = catalog.serverPrices && catalog.serverPrices[serverId];
    const v = canon && primary && primary[canon.id];
    // 同名道具可能属于不同物品表；目录脚本使用的 key 必须与突破道具一致。
    if (v > 0 && QUOTE_KEYS[itemOf(idx).n] === itemOf(idx).k) return { v: v, src: 'catalog-jx3box', at: catalog.meta.priceUpdatedAt };
    const snap = (BT.prices[serverId] || [])[idx];
    if (snap > 0) return { v: snap, src: 'breakthrough-jx3box', at: META.priceUpdatedAt };
    return { v: null, src: 'missing', at: null };
  }
  function gatherPrice(id, serverId) {
    const it = byId[id];
    const idx = it && indexByName[it.name];
    if (idx != null) {
      const hit = priceOfIndex(idx, serverId);
      if (hit.v > 0) return hit;
    }
    // 突破报价表缺这个道具时，回退目录行情（含示例价），否则采集点收益会是 null
    const p = catalog.serverPrices && catalog.serverPrices[serverId];
    return p && p[id] > 0 ? { v: p[id], src: 'catalog-jx3box' } : { v: null, src: 'missing' };
  }
  function costTable(serverId, basis, mode) {
    const memo = [];
    function cost(idx, stack) {
      if (memo[idx]) return memo[idx];
      const p = priceOfIndex(idx, serverId);
      const base = { v: p.v, market: p.v, src: p.src, missing: p.v == null, recipe: null };
      if (basis !== 'min' || stack.indexOf(idx) !== -1) return base;
      let best = base;
      (producers[idx] || []).forEach(function (r) {
        const qty = (r.o || []).reduce(function (s, o) { return s + (o[0] === idx ? quantity(o, mode) : 0); }, 0);
        if (!(qty > 0)) return;
        let v = 0, missing = false;
        (r.m || []).forEach(function (m) { const c = cost(m[0], stack.concat(idx)); if (c.missing) missing = true; else v += c.v * m[1]; });
        if (!missing && (best.missing || v / qty < best.v - 1e-9)) best = { v: v / qty, market: p.v, src: 'craft', recipe: r, missing: false };
      });
      memo[idx] = best;
      return best;
    }
    items.forEach(function (_, idx) { memo[idx] = cost(idx, []); });
    return memo;
  }
  function recipeEcon(r, serverId, table, taxRate, mode) {
    const mats = (r.m || []).map(function (m) { const c = table[m[0]]; return { idx: m[0], qty: m[1], unit: c.v, src: c.src, missing: c.missing, sub: c.missing ? null : c.v * m[1] }; });
    const outs = (r.o || []).map(function (o) { const p = priceOfIndex(o[0], serverId), qty = quantity(o, mode); return { idx: o[0], min: o[1], max: o[2], chance: chanceOf(o[3]), qty: qty, unit: p.v, missing: p.v == null && qty > 0, sub: p.v == null && qty > 0 ? null : (p.v || 0) * qty }; });
    const matCost = mats.some(function (m) { return m.missing; }) ? null : mats.reduce(function (s, m) { return s + m.sub; }, 0);
    const gross = outs.some(function (o) { return o.missing; }) ? null : outs.reduce(function (s, o) { return s + o.sub; }, 0);
    const netValue = gross == null ? null : gross * (1 - taxRate);
    const profit = matCost == null || netValue == null ? null : netValue - matCost;
    const energy = num(r.e);
    const exp = energy > 0 ? energy * CRAFT_EXP_PER_ENERGY : 0;
    return { mats: mats, outs: outs, matCost: matCost, gross: gross, netValue: netValue, profit: profit, exp: exp, energy: energy, missing: profit == null, profitPerExp: profit == null || !(exp > 0) ? null : profit / exp };
  }
  const expModel = META.expModel || { base: 500, step: 25 };
  const observations = (expModel.observations || []).slice().sort(function (a, b) { return a.level - b.level; });
  // 30→50 级采集与制造的经验表不同（2026-11-25 用户实测图）：
  // 采集（庖丁）30→50 合计 35,840，制造（烹饪）48,580；1→30 级暂共用实测表。
  const categoryObservations = {
    gather: (expModel.categories && expModel.categories.gather || []).slice().sort(function (a, b) { return a.level - b.level; }),
    craft: (expModel.categories && expModel.categories.craft || []).slice().sort(function (a, b) { return a.level - b.level; })
  };
  function validObservations(list, label) {
    if (!list.length) return;
    const invalid = list.some(function (p, i) {
      return !Number.isInteger(p.level) || p.level < 1 || p.level >= CAP || !Number.isFinite(p.exp) || p.exp <= 0 ||
        (i > 0 && (p.level === list[i - 1].level || p.exp < list[i - 1].exp));
    });
    if (invalid) throw new Error('Invalid experience observations' + (label ? ' (' + label + ')' : ''));
  }
  if (expModel.method === 'piecewise-linear') {
    if (observations.length < 2) throw new Error('Invalid experience observations');
    validObservations(observations, '');
    validObservations(categoryObservations.gather, 'gather');
    validObservations(categoryObservations.craft, 'craft');
  }
  function experienceAt(level, kind) {
    if (!Number.isInteger(level) || level < 1 || level >= CAP) return { need: null, source: 'unavailable', estimated: true };
    if (expModel.method !== 'piecewise-linear') return { need: Math.max(1, Math.round(num(expModel.base) + num(expModel.step) * (level - 1))), source: 'estimated', estimated: true };
    // 30 级起按技艺类别取对应表；1–29 级没有分类数据，继续用共用实测表。
    const category = categoryObservations[kind];
    const useCategory = !!(category && category.length && level >= category[0].level && level <= category[category.length - 1].level);
    const table = useCategory ? category : observations;
    const observed = table.find(function (p) { return p.level === level; });
    if (observed) return { need: observed.exp, source: 'observed', estimated: false };
    let upper = table.findIndex(function (p) { return p.level > level; });
    const extrapolated = upper < 0 || upper === 0;
    if (upper < 0) upper = table.length - 1;
    if (upper === 0) upper = 1;
    const a = table[upper - 1], b = table[upper];
    const estimate = a.exp + (b.exp - a.exp) * (level - a.level) / (b.level - a.level);
    const step = num(expModel.roundTo) || 1;
    return { need: Math.max(1, Math.round(estimate / step) * step), source: extrapolated ? 'extrapolated' : 'interpolated', estimated: true };
  }
  function expToNext(level, kind) { return experienceAt(level, kind || 'gather').need; }
  function experienceRows(kind) {
    const type = kind || 'gather';
    let cumulative = 0;
    return Array.from({ length: CAP - 1 }, function (_, i) { const point = experienceAt(i + 1, type); cumulative += point.need; return { from: i + 1, to: i + 2, need: point.need, cumulative: cumulative, source: point.source, estimated: point.estimated }; });
  }
  function gateInfo(g, serverId, basis, table) {
    const entries = (g.r || []).map(function (m) {
      const p = priceOfIndex(m[0], serverId), c = table[m[0]];
      const useCraft = basis === 'min' && c.src === 'craft';
      // 突破材料缺少本服报价时，保留自制成本参考，但不把它当成完整任务报价。
      const unit = p.v == null ? null : useCraft ? c.v : p.v;
      return { idx: m[0], name: itemOf(m[0]).n, qty: m[1], unit: unit, market: p.v, craft: c.src === 'craft' ? c.v : null, src: useCraft ? c.src : p.src, recipe: c.recipe || (producers[m[0]] || [])[0] || null, sub: unit == null ? null : unit * m[1], missing: unit == null };
    });
    const missingItems = entries.filter(function (i) { return i.missing; });
    const knownCost = entries.reduce(function (s, i) { return s + (i.sub == null ? 0 : i.sub); }, 0);
    return { level: g.l, name: g.n, items: entries, missingItems: missingItems, missing: missingItems.length > 0, knownCost: knownCost, cost: missingItems.length ? null : knownCost, marketCost: entries.some(function (i) { return i.market == null; }) ? null : entries.reduce(function (s, i) { return s + i.market * i.qty; }, 0) };
  }
  function gatherOutputs(recipe, serverId) {
    const state = getState(), taxRate = Math.max(0, Math.min(1, num(state.settings && state.settings.taxRate)));
    return (recipe.outputs || []).map(function (o) {
      const p = gatherPrice(o.item, serverId || state.serverId), chance = chanceOf(o.chance);
      return { name: byId[o.item] ? byId[o.item].name : o.item, qty: o.qty, chance: chance, unit: p.v, missing: p.v == null && o.qty * chance > 0, sub: p.v == null && o.qty * chance > 0 ? null : (p.v || 0) * o.qty * chance * (1 - taxRate) };
    });
  }
  function aggregate(rows, gates) {
    const t = { exp: 0, energy: 0, crafts: 0, matCost: 0, outValue: 0, profit: 0, gateCost: 0, gateMarket: 0, knownGateCost: 0, missingLevels: 0, missingGates: 0, missingPriceLevels: 0 };
    let bandValue = 0, bandEnergy = 0;
    rows.forEach(function (r) {
      t.exp += r.need;
      if (!r.recipe) { t.missingLevels++; return; }
      t.energy += r.totalEnergy; t.crafts += r.count;
      if (r.band && r.band.mean != null) { bandValue += r.band.mean * r.totalEnergy; bandEnergy += r.totalEnergy; }
      if (r.profit == null) t.missingPriceLevels++;
      ['matCost', 'outValue', 'profit'].forEach(function (k) { t[k] = t[k] == null || r[k] == null ? null : t[k] + r[k]; });
    });
    gates.forEach(function (g) { t.knownGateCost += g.knownCost; if (g.missing) t.missingGates++; else t.gateCost += g.cost; });
    t.gateMarket = gates.some(function (g) { return g.marketCost == null; }) ? null : gates.reduce(function (s, g) { return s + g.marketCost; }, 0);
    if (t.missingLevels) ['energy', 'crafts', 'matCost', 'outValue', 'profit'].forEach(function (k) { t[k] = null; });
    if (t.missingGates) t.gateCost = null;
    t.total = t.profit == null || t.gateCost == null ? null : t.profit - t.gateCost;
    t.netCost = t.total == null ? null : -t.total;
    t.bandMean = !t.missingLevels && bandEnergy > 0 ? bandValue / bandEnergy : null;
    return t;
  }
  function profitBand(available, mode) {
    if (!available.length) return { key: mode, count: 0, mean: null, min: null, max: null, pool: [] };
    const ratios = available.map(function (c) { return c.e.profit / c.e.energy; });
    const min = Math.min.apply(null, ratios), max = Math.max.apply(null, ratios), width = (max - min) / 3;
    const slot = { low: 0, mid: 1, high: 2 }[mode];
    const lower = min + width * slot, upper = min + width * (slot + 1);
    const pool = available.filter(function (c) { const ratio = c.e.profit / c.e.energy; return width < 1e-9 || (ratio >= lower && (slot === 2 ? ratio <= max : ratio < upper)); });
    return { key: mode, min: lower, max: upper, count: pool.length, mean: pool.length ? pool.reduce(function (s, c) { return s + c.e.profit / c.e.energy; }, 0) / pool.length : null, pool: pool };
  }
  function analyze(skillId, strategy, mode) {
    if (strategy === 'effort') strategy = 'energy';
    mode = MODES.some(function (m) { return m.key === mode; }) ? mode : 'high';
    // 精力/次数策略只生成一条路线，产量统一使用区间中点。
    if (strategy !== 'gold') mode = 'mid';
    const state = getState(), serverId = state.serverId;
    const basis = state.settings && state.settings.basis || 'market';
    const taxRate = Math.max(0, Math.min(1, num(state.settings && state.settings.taxRate)));
    const meta = skillMeta(skillId), gather = meta.type === 'gather';
    const expKind = gather ? 'gather' : 'craft';
    // 档位表示金/精力的数值区间，不表示产量；所有策略统一用产量中点。
    const table = costTable(serverId, basis, 'mid');
    const pool = gather ? (catalog.recipes || []).filter(function (r) { return r.kind === 'gather' && r.skillId === skillId; }) : recipes.filter(function (r) { return r.s === skillId; }).sort(function (a, b) { return a.l - b.l || String(a.n).localeCompare(String(b.n), 'zh-CN'); });
    const gatherEcon = function (r) {
      const outs = gatherOutputs(r, serverId), missing = outs.some(function (o) { return o.missing; });
      const value = missing ? null : outs.reduce(function (s, o) { return s + o.sub; }, 0);
      const gEnergy = num(r.energy);
      const e = { exp: gEnergy > 0 ? gEnergy * GATHER_EXP_PER_ENERGY : 0, energy: gEnergy, matCost: 0, netValue: value, profit: value, missing: missing };
      e.profitPerExp = value == null ? null : value / e.exp;
      return e;
    };
    const candidates = pool.map(function (r) {
      return { r: r, e: gather ? gatherEcon(r) : recipeEcon(r, serverId, table, taxRate, 'mid') };
    });
    // 目录缺失的采集点（例如采金·银矿）按实测等级与 40 精力合成，只用于算精力
    if (gather) {
      (GATHER_EXTRAS[skillId] || []).forEach(function (pt) {
        const node = synthGatherNode(pt.name, pt.energy, pt.level || 1, skillId);
        candidates.push({ r: node, e: gatherEcon(node) });
      });
    }
    const levels = experienceRows(expKind).map(function (xp) {
      let pick = null;
      // 采集点也有等级限制：只有当前等级已解锁的矿/草/兽才能采。
      // 目录里采金最低 20 级、庖丁最低 20 级，所以 1–19 级确实无点可采（数据缺口），
      // 庖丁的秒刷点由 GATHER_PLANS 单独指定，不走这个门禁。
      const levelOk = function (c) { return gather ? gatherLevelOf(c.r) <= xp.from : c.r.l <= xp.from; };
      const usable = candidates.filter(function (c) { return levelOk(c) && c.e.exp > 0 && c.e.energy > 0; });
      let available = usable.filter(function (c) { return strategy !== 'gold' || !c.e.missing; });
      // 采集：金币路线优先用有报价的采集动作；整级都没报价时仍给出精力路线（收益留空），
      // 否则采金/庖丁这类缺报价的采集技艺会整条路线都算不出来。
      // 制造保持原口径：没有报价就视为无法核算，避免把缺价当成 0 收益。
      if (!available.length && gather) available = usable;
      // 指定采集路线：例如庖丁 1–30 用西湖草龟/成都雌鹿的秒刷点，30 级后改黑山羊。
      const plan = gather && GATHER_PLANS[skillId]
        ? GATHER_PLANS[skillId].find(function (p) { return xp.from >= p.from && xp.from < p.to; })
        : null;
      const planPool = plan ? plan.points.map(function (pt) {
        const hit = candidates.find(function (c) { return String((c.r && (c.r.n || c.r.name)) || '').indexOf(pt.name) !== -1; });
        if (hit) return hit;
        // 目录里没有这个采集点：按实测比例合成（经验 = 精力×3.2），收益标为缺价
        const node = synthGatherNode(pt.name, pt.energy, pt.level || 1, skillId);
        return { r: node, e: gatherEcon(node) };
      }).filter(function (c) { return c.e.exp > 0 && c.e.energy > 0; }) : null;
      // 金币最优：不再分低/中/高收益比档，直接在所有可用配方里比较总净花费
      (planPool || available).forEach(function (c) {
        // 采集按「当前最高可用采集点」走：经验/精力比固定 3.2，各点只差在掉率与价格，
        // 按等级递进才符合实际刷点顺序（神农 25 级起紫苏、30 级起鱼腥草/黄花菜）。
        if (gather) {
          const levelOfNode = function (rr) { return gatherLevelOf(rr); };
          if (!pick || levelOfNode(c.r) > levelOfNode(pick.r)) pick = c;
          return;
        }
        function score(e) { const count = Math.ceil(xp.need / e.exp); if (strategy === 'energy') return count * e.energy; return -count * e.profit; }
        const tied = pick && Math.abs(score(c.e) - score(pick.e)) <= 1e-9;
        // 精力最优：次数相同时，优先用当前等级刚解锁的更高阶采集点（例如神农 25 级起采紫苏、30 级起采鱼腥草/黄花菜）
        const levelOf = function (rr) { return gather ? gatherLevelOf(rr) : num(rr.l); };
        const sameCount = pick && Math.ceil(xp.need / c.e.exp) === Math.ceil(xp.need / pick.e.exp);
        const higherNode = pick && sameCount && c.e.energy === pick.e.energy && levelOf(c.r) > levelOf(pick.r);
        const tieBetter = pick && (strategy === 'gold'
          ? c.e.energy / c.e.exp < pick.e.energy / pick.e.exp
          : (Math.ceil(xp.need / c.e.exp) < Math.ceil(xp.need / pick.e.exp) || higherNode));
        if (!pick || score(c.e) < score(pick.e) - 1e-9 || (tied && tieBetter)) pick = c;
      });
      const r = pick && pick.r, e = pick && pick.e;
      // 采集：30 级前按 40 精力=128 经验，30 级后统一 1 精力=2 经验。
      const actionExp = e ? (gather ? e.energy * gatherExpPerEnergyAt(xp.from) : e.exp) : null;
      const count = e ? Math.ceil(xp.need / actionExp) : null;
      return { kind: 'level', from: xp.from, to: xp.to, need: xp.need, name: r ? (r.n || r.name) : '无符合等级的可用路线', level: r ? (gather ? r.level : r.l) : null, recipe: r, econ: e, band: null, exp: actionExp, energy: e ? e.energy : null, count: count, matCost: e && e.matCost != null ? e.matCost * count : null, outValue: e && e.netValue != null ? e.netValue * count : null, profit: e && e.profit != null ? e.profit * count : null, totalEnergy: e ? e.energy * count : null };
    });
    const gates = (BT.gates[skillId] || []).filter(function (g) { return GATE_LEVELS.indexOf(g.l) !== -1; }).map(function (g) { return gateInfo(g, serverId, basis, table); });
    const bands = [];
    levels.forEach(function (r) {
      const prev = bands[bands.length - 1];
      if (prev && prev.recipe === r.recipe && JSON.stringify(prev.band) === JSON.stringify(r.band) && GATE_LEVELS.indexOf(prev.to) === -1) {
        prev.to = r.to; prev.need += r.need;
        ['count', 'matCost', 'outValue', 'profit', 'totalEnergy'].forEach(function (k) { prev[k] = prev[k] == null || r[k] == null ? null : prev[k] + r[k]; });
      } else bands.push(Object.assign({}, r));
    });
    const routes = [];
    bands.forEach(function (r) { routes.push(r); const gate = gates.find(function (g) { return g.level === r.to; }); if (gate) routes.push(Object.assign({ kind: 'gate' }, gate)); });
    routes.push({ kind: 'max', level: CAP, name: '50 级 · 满级（无独立突破任务）' });
    const totals = aggregate(levels, gates);
    const phases = [{ from: 1, to: 30 }, { from: 30, to: CAP }].map(function (p) { return Object.assign({}, p, aggregate(levels.filter(function (r) { return r.from >= p.from && r.from < p.to; }), gates.filter(function (g) { return p.from === 1 ? g.level === 30 : g.level > 30; }))); });
    return { kind: gather ? 'gather' : 'craft', skillId: skillId, strategy: strategy, mode: mode, meta: meta, levels: levels, experience: experienceRows(expKind), routes: routes, gates: gates, phases: phases, totals: totals, enough: strategy === 'gold' ? totals.total != null : !totals.missingLevels };
  }
  function summary(strategy, mode) {
    return SKILL_IDS.map(function (id) { const r = analyze(id, strategy, mode); return Object.assign({ skillId: id, name: r.meta.name, color: r.meta.color, type: r.meta.type, enough: r.enough }, r.totals); }).sort(function (a, b) { const key = strategy === 'energy' ? 'energy' : strategy === 'effort' ? 'crafts' : 'netCost'; if (a[key] == null) return b[key] == null ? 0 : 1; if (b[key] == null) return -1; return a[key] - b[key]; });
  }
  function itemsText(r, limit) {
    if (!r) return '';
    if (r.kind === 'gather') return (r.outputs || []).slice(0, limit || 2).map(function (o) { return (byId[o.item] ? byId[o.item].name : o.item) + '×' + o.qty + (chanceOf(o.chance) < 1 ? '（' + Math.round(chanceOf(o.chance) * 100) + '%）' : ''); }).join(' + ');
    return (r.o || []).slice(0, limit || 2).map(function (o) { return itemOf(o[0]).n + '×' + (o[1] === o[2] ? o[1] : o[1] + '~' + o[2]) + (chanceOf(o[3]) < 1 ? '（' + Math.round(chanceOf(o[3]) * 100) + '%）' : ''); }).join(' + ');
  }
  function matsText(r, limit) { return r ? (r.m || []).slice(0, limit || 3).map(function (m) { return itemOf(m[0]).n + '×' + m[1]; }).join(' · ') : ''; }
  return { META: META, CAP: CAP, GATE_LEVELS: GATE_LEVELS, SKILL_IDS: SKILL_IDS, MODES: MODES, analyze: analyze, summary: summary, expToNext: expToNext, experienceRows: experienceRows, itemOf: itemOf, priceOfIndex: priceOfIndex, gatherOutputs: gatherOutputs, itemsText: itemsText, matsText: matsText, formatRange: function (from, to) { return from + '→' + to + ' 级'; } };
}
if (typeof module !== 'undefined' && module.exports) module.exports = createBreakthrough;
else window.createJX3Breakthrough = createBreakthrough;
